#!/bin/bash
# QGI Theory - PDF Compilation Script
# Author: Marcos Eduardo de Aquino Junior
# Date: 2025-01-13

echo "════════════════════════════════════════════════════════════════"
echo "    QGI THEORY - PDF COMPILATION"
echo "════════════════════════════════════════════════════════════════"
echo ""

# Check if pdflatex is available
if ! command -v pdflatex &> /dev/null; then
    echo "❌ ERROR: pdflatex not found!"
    echo ""
    echo "Please install LaTeX:"
    echo "  macOS: brew install --cask mactex"
    echo "  Linux: sudo apt-get install texlive-full"
    echo ""
    exit 1
fi

echo "✓ pdflatex found"
echo ""
echo "Compiling QGI manuscript..."
echo "────────────────────────────────────────────────────────────────"

# First compilation
echo ""
echo "Step 1/4: First pdflatex run..."
pdflatex -interaction=nonstopmode main.tex > compile.log 2>&1
if [ $? -eq 0 ]; then
    echo "✓ First pass completed"
else
    echo "❌ Error in first pass - check compile.log"
    tail -20 compile.log
    exit 1
fi

# Run biber for bibliography
echo ""
echo "Step 2/4: Processing bibliography (biber)..."
biber main >> compile.log 2>&1
if [ $? -eq 0 ]; then
    echo "✓ Bibliography processed"
else
    echo "⚠️  Biber had warnings (check compile.log)"
fi

# Second compilation
echo ""
echo "Step 3/4: Second pdflatex run (cross-references)..."
pdflatex -interaction=nonstopmode main.tex >> compile.log 2>&1
if [ $? -eq 0 ]; then
    echo "✓ Second pass completed"
else
    echo "❌ Error in second pass - check compile.log"
    exit 1
fi

# Third compilation
echo ""
echo "Step 4/4: Third pdflatex run (final)..."
pdflatex -interaction=nonstopmode main.tex >> compile.log 2>&1
if [ $? -eq 0 ]; then
    echo "✓ Third pass completed"
else
    echo "❌ Error in third pass - check compile.log"
    exit 1
fi

echo ""
echo "════════════════════════════════════════════════════════════════"
echo "✅ PDF GENERATED SUCCESSFULLY!"
echo "════════════════════════════════════════════════════════════════"
echo ""
echo "Output file: main.pdf"

if [ -f main.pdf ]; then
    SIZE=$(du -h main.pdf | cut -f1)
    PAGES=$(pdfinfo main.pdf 2>/dev/null | grep Pages | awk '{print $2}')
    echo "Size: $SIZE"
    if [ ! -z "$PAGES" ]; then
        echo "Pages: $PAGES"
    fi
    echo ""
    echo "✓ Ready for submission!"
else
    echo "❌ main.pdf not found - compilation may have failed"
    exit 1
fi

echo ""
echo "To view the PDF:"
echo "  macOS: open main.pdf"
echo "  Linux: xdg-open main.pdf"
echo ""
echo "════════════════════════════════════════════════════════════════"






