#!/bin/bash
# Pre-Push Verification Script
# Run this before pushing to GitHub to ensure everything is ready

echo "================================================================================"
echo "🔍 PRE-PUSH VERIFICATION - QGI Theory"
echo "================================================================================"
echo "Date: $(date)"
echo "================================================================================"

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

ERRORS=0
WARNINGS=0

# Check 1: Required files exist
echo ""
echo "📋 CHECK 1: Required Files"
echo "--------------------------------------------------------------------------------"

required_files=(
    "README.md"
    "LICENSE"
    "CHANGELOG.md"
    "CONTRIBUTING.md"
    "requirements.txt"
    "environment.yml"
    "manuscript/main.tex"
    "manuscript/referencias.bib"
    "validation/QGI_validation.py"
)

for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
    else
        echo -e "${RED}✗${NC} $file (MISSING)"
        ((ERRORS++))
    fi
done

# Check 2: Figure files
echo ""
echo "🖼️  CHECK 2: Figures"
echo "--------------------------------------------------------------------------------"

fig_count=$(find figures/ -name "*.pdf" 2>/dev/null | wc -l | tr -d ' ')
echo "PDF figures found: $fig_count"

if [ "$fig_count" -ge 9 ]; then
    echo -e "${GREEN}✓${NC} Sufficient figures ($fig_count >= 9)"
else
    echo -e "${YELLOW}⚠${NC}  Only $fig_count figures (expected 9+)"
    ((WARNINGS++))
fi

# Check 3: Python scripts
echo ""
echo "🐍 CHECK 3: Python Scripts"
echo "--------------------------------------------------------------------------------"

if command -v python3 &> /dev/null; then
    echo -e "${GREEN}✓${NC} Python3 installed: $(python3 --version)"
    
    # Try running validation
    echo "  Running QGI_validation.py..."
    cd validation
    if python3 QGI_validation.py > /tmp/qgi_val.txt 2>&1; then
        if grep -q "ALL TESTS PASSED" /tmp/qgi_val.txt; then
            echo -e "  ${GREEN}✓${NC} Validation passed (8/8 tests)"
        else
            echo -e "  ${RED}✗${NC} Validation failed"
            ((ERRORS++))
        fi
    else
        echo -e "  ${RED}✗${NC} Script error"
        ((ERRORS++))
    fi
    cd ..
else
    echo -e "${YELLOW}⚠${NC}  Python3 not found (needed for validation)"
    ((WARNINGS++))
fi

# Check 4: File sizes
echo ""
echo "💾 CHECK 4: File Sizes"
echo "--------------------------------------------------------------------------------"

total_size=$(du -sh . 2>/dev/null | awk '{print $1}')
echo "Total size: $total_size"

if command -v numfmt &> /dev/null; then
    size_bytes=$(du -sb . 2>/dev/null | awk '{print $1}')
    if [ "$size_bytes" -lt 50000000 ]; then  # 50 MB
        echo -e "${GREEN}✓${NC} Size OK for GitHub (<50 MB)"
    else
        echo -e "${YELLOW}⚠${NC}  Large repository (${total_size})"
        ((WARNINGS++))
    fi
fi

# Check 5: Git status
echo ""
echo "📦 CHECK 5: Git Status"
echo "--------------------------------------------------------------------------------"

if [ -d ".git" ]; then
    echo -e "${GREEN}✓${NC} Git repository initialized"
    
    # Check for uncommitted changes
    if [ -n "$(git status --porcelain)" ]; then
        echo -e "${YELLOW}⚠${NC}  Uncommitted changes exist"
        echo "  Run: git add . && git commit -m 'Your message'"
        ((WARNINGS++))
    else
        echo -e "${GREEN}✓${NC} No uncommitted changes"
    fi
    
    # Check for remote
    if git remote -v | grep -q "origin"; then
        echo -e "${GREEN}✓${NC} Remote 'origin' configured"
    else
        echo -e "${YELLOW}⚠${NC}  No remote configured"
        echo "  Run: git remote add origin https://github.com/USER/REPO.git"
        ((WARNINGS++))
    fi
else
    echo -e "${YELLOW}⚠${NC}  Not a git repository"
    echo "  Run: git init"
    ((WARNINGS++))
fi

# Check 6: Documentation completeness
echo ""
echo "📚 CHECK 6: Documentation"
echo "--------------------------------------------------------------------------------"

doc_files=(
    "README.md"
    "docs/INSTALLATION.md"
    "docs/USAGE.md"
    "docs/REPRODUCIBILITY.md"
)

for doc in "${doc_files[@]}"; do
    if [ -f "$doc" ] && [ -s "$doc" ]; then
        lines=$(wc -l < "$doc" | tr -d ' ')
        if [ "$lines" -gt 50 ]; then
            echo -e "${GREEN}✓${NC} $doc ($lines lines)"
        else
            echo -e "${YELLOW}⚠${NC}  $doc might be incomplete ($lines lines)"
            ((WARNINGS++))
        fi
    else
        echo -e "${RED}✗${NC} $doc missing or empty"
        ((ERRORS++))
    fi
done

# Check 7: No sensitive data
echo ""
echo "🔒 CHECK 7: Security"
echo "--------------------------------------------------------------------------------"

# Check for common sensitive patterns
if grep -r "password\|secret\|api_key\|token" --include="*.py" --include="*.txt" . 2>/dev/null | grep -v "# " > /dev/null; then
    echo -e "${YELLOW}⚠${NC}  Potential sensitive data found (review manually)"
    ((WARNINGS++))
else
    echo -e "${GREEN}✓${NC} No obvious sensitive data"
fi

# Check for large files
echo ""
large_files=$(find . -type f -size +10M 2>/dev/null)
if [ -n "$large_files" ]; then
    echo -e "${YELLOW}⚠${NC}  Large files found (>10 MB):"
    echo "$large_files"
    ((WARNINGS++))
else
    echo -e "${GREEN}✓${NC} No files >10 MB"
fi

# Final report
echo ""
echo "================================================================================"
echo "FINAL REPORT"
echo "================================================================================"

if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}"
    echo "🎉 ALL CHECKS PASSED!"
    echo ""
    echo "✅ Ready to push to GitHub"
    echo "✅ No errors found"
    echo "✅ No warnings"
    echo -e "${NC}"
    echo "Next step:"
    echo "  git push -u origin main"
    exit 0
elif [ $ERRORS -eq 0 ]; then
    echo -e "${YELLOW}"
    echo "⚠️  CHECKS PASSED WITH WARNINGS"
    echo ""
    echo "✅ No critical errors"
    echo "⚠️  $WARNINGS warning(s) - review above"
    echo -e "${NC}"
    echo "You can proceed, but review warnings first."
    exit 0
else
    echo -e "${RED}"
    echo "❌ CHECKS FAILED"
    echo ""
    echo "✗ $ERRORS error(s) found"
    echo "⚠️  $WARNINGS warning(s)"
    echo -e "${NC}"
    echo "Fix errors before pushing."
    exit 1
fi

